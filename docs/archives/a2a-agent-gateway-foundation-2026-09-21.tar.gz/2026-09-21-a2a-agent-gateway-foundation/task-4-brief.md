### Task 4: Create the agent gateway, registry, and pinned official A2A client

**Files:**
- Create: `thought-khoral-agent-gateway/{Cargo.toml,Cargo.lock,docs/dependencies/a2a-rs.md}`
- Create: `thought-khoral-agent-gateway/src/{lib,config,domain,registry,room_client}.rs`, `thought-khoral-agent-gateway/src/bin/thought-khoral-agent-gateway.rs`
- Create: `thought-khoral-agent-gateway/tests/{config,registry,room_client}_test.rs`

**Interfaces:** Produces `RegisteredAgent`, `RoomContextPacket`, `AgentTaskLease`, and `RoomGatewayClient::{claim,fetch_context,submit_update}`.

- [ ] **Step 1: Record official dependency evidence**

Write `docs/dependencies/a2a-rs.md` with official repo/release URL, exact crate/version, tag/commit, Apache-2.0 evidence, supported HTTP/JSON-RPC/SSE bindings, MSRV, and advisory-check command/date. Use only official core/client crates in this slice.

- [ ] **Step 2: Write failing config/registry/client tests**

```rust
#[test] fn registry_rejects_card_endpoint_or_skill_drift() {
    let mut card = fixed_reference_card();
    card.skills.clear();
    assert!(RegisteredAgent::from_pinned_card(reference_registration(), card).is_err());
}
#[test] fn config_rejects_non_loopback_agent_or_unallowlisted_handoff_host() {
    assert!(GatewayConfig::parse(test_env("https://remote-agent.invalid", "allowed.example")).is_err());
    assert!(GatewayConfig::parse(test_env("http://127.0.0.1:9090", "unregistered.example")).is_err());
}
#[tokio::test] async fn room_client_never_forwards_a_user_access_token() {
    let server = recording_mock_room_gateway().await;
    RoomGatewayClient::for_test(server.url(), service_token_provider()).claim(test_claim()).await.unwrap();
    assert_eq!(server.last_authorization().await, Some("Bearer service-token".into()));
}
```

- [ ] **Step 3: Run red**

Run: `cargo test --test config_test --test registry_test --test room_client_test`

Expected: FAIL because the crate is absent.

- [ ] **Step 4: Implement strict local configuration and registry**

```rust
pub struct RegisteredAgent { pub id: Uuid, pub display_name: String, pub card_url: Url, pub allowed_skills: BTreeSet<SkillId>, pub allowed_handoff_hosts: BTreeSet<String> }
```

Require Keycloak token URL/client ID/secret, exact room-gateway origin, fixed Agent Card URL/host, allowed skills, lease/poll/rate limits. Pin Card identity, skills, binding, and endpoint at startup. `RoomGatewayClient` uses client credentials only for the configured room-gateway origin.

- [ ] **Step 5: Pin the SDK and verify green**

Run: `cargo metadata --locked --format-version 1 && cargo tree -i a2a-client-lf && cargo test --all-targets`

Expected: PASS; only the selected official A2A release is locked.

- [ ] **Step 6: Commit**

```bash
cd thought-khoral-agent-gateway && git add Cargo.toml Cargo.lock src tests docs/dependencies && git commit -m "feat: add zero-trust A2A agent gateway foundation"
```

