# Task 6 report — governed external-agent task UI

Committed in `thought-khoral-workspace-ui` as:

`579f94a feat: show governed external agent tasks`

## Scope

The UI now projects the published external-agent task lifecycle for the fixed
Reference Agent (`74686f75-6768-746b-686f-72616c000003`) and only the
`summarize-context` and `extract-action-items` skills. The existing Action
Items cards and ordinary @mention message flow remain intact; mentions do not
start agent work.

`AgentTaskComposer` is rendered only for human room participants. It limits
input to 8,000 characters and constructs the sole explicit task-start request
through `createRpcRequest('agent.task.start', roomId, ...)`. The socket sends
that exact request without regenerating it.

## Safety controls

- External task events are validated at the UI boundary: exact fixed agent,
  known skill and phase, UUID/task core, bounded content, closed result unions,
  unique UUID citations, bounded action items, and closed failure codes.
- Handoffs are only accepted for valid HTTPS URLs without credentials whose
  actual host exactly matches the supplied host. They render as data plus a
  human-click anchor using `target="_blank"` and `rel="noopener noreferrer"`.
  There is no auto-navigation or `window.open` path.
- Results are rendered as React text, never returned HTML. Citation controls
  locate the existing persisted event element, scroll it into view, and focus
  it; they do not navigate.

## TDD evidence

The required focused RED command was first attempted before dependencies were
installed and stopped with `vitest: command not found`. After `npm ci`, the
same command ran and failed as intended because the composer and external task
projection/rendering were absent:

```text
npm test -- --run src/api.test.ts src/features/room/ChatStream.test.tsx src/features/room/AgentTaskComposer.test.tsx

FAIL AgentTaskComposer.test.tsx: failed to resolve AgentTaskComposer
FAIL api.test.ts: external task fields were not projected / malformed handoff projected
FAIL ChatStream.test.tsx: governed card and handoff link were absent
```

The focused GREEN run passed all 34 tests. The final suite includes explicit
requested → progressed → succeeded assertions for both supported skills, plus
the safe card, citation focus/scroll, handoff anchor, fixed ID, trimmed start
payload, and 8,000-character limit checks.

## Final verification

```text
npm test              # passed: 7 files, 78 tests
npm run build          # passed: TypeScript check and Vite production build
npm run test:preview   # passed: visible production Room conversation; 17 ChatStream tests
git diff --check       # passed
```

The Vite build emitted its pre-existing advisory about chunks larger than
500 kB; it did not fail the build.

## Fix round 1 — decision citations and terminal handoff cleanup

Committed in `thought-khoral-workspace-ui` as:

`4f60e97 fix: retain governed task citation targets`

Active decisions are now citeable alongside persisted event IDs. The decision
card provides stable focus targets for its own persisted decision ID and every
persisted source event ID; a citation first targets its event element, then an
active decision, then an active decision-source target. The projection keeps
only citations backed by a persisted event or an active decision/source.

An `awaiting_external_input` handoff is explicitly cleared when the lifecycle
reaches either terminal state (`succeeded` or `failed`), so no expired external
continuation link survives a result or failure.

The generic socket `send` method no longer accepts `agent.task.start` at the
type boundary. The human-only composer retains the explicit preconstructed
request path through `sendRequest`.

New RED tests failed before the change because active-decision citations were
dropped, terminal tasks retained their prior handoff, and decision citation
targets did not exist. Focused GREEN verification then passed:

```text
npm test -- --run src/api.test.ts src/features/room/ChatStream.test.tsx src/features/decisions/DecisionCard.test.tsx
# passed: 3 files, 53 tests
```

Fresh final verification passed:

```text
npm test              # passed: 7 files, 81 tests
npm run build          # passed
npm run test:preview   # passed: 18 ChatStream tests
git diff --check       # passed
```
