### Task 7: Compose isolated local services and prove the vertical slice

**Files:**
- Create: `thought-khoral-platform/containers/{agent-gateway,reference-agent}.Containerfile`, `thought-khoral-platform/kube/{agent-gateway,reference-agent}.yaml`, `thought-khoral-platform/scripts/smoke-agent-gateway.mjs`
- Modify: `thought-khoral-platform/{compose.yaml,README.md,keycloak/thought-khoral-dev-realm.json,scripts/smoke.sh,scripts/validate-kube.sh}`
- Create: `thought-khoral-agent-gateway/docs/verification/a2a-foundation.md`

**Interfaces:** Runs room gateway, agent gateway, and reference agent with internal-only service paths.

- [ ] **Step 1: Write smoke assertions before Compose changes**

Require services `thought-khoral-agent-gateway` and `thought-khoral-reference-agent`; neither may publish a host port or get `DATABASE_URL`. Require non-root/read-only/no-new-privileges/tmpfs. Require an internal task for both skills to emit progress then exactly one cited terminal result.

- [ ] **Step 2: Run red**

Run: `cd thought-khoral-platform && bash scripts/smoke.sh`

Expected: FAIL because services and assertions are missing.

- [ ] **Step 3: Add Compose/container/Kubernetes identity and isolation**

Build two agent-gateway binaries, configure only Keycloak service credentials/room endpoint/Card endpoint/shared inbound secret, and do not expose reference-agent port. Add matching non-root read-only internal Kubernetes Services; leave production mTLS/workload identity configuration to deployment secret management, never checked-in certificates.

- [ ] **Step 4: Add full smoke and platform validation**

`smoke-agent-gateway.mjs` authenticates Alice, creates a fresh room, invokes both skills, waits for expected event order, validates citations, and asserts a hidden targeted message is absent from the captured packet test endpoint/harness.

Run: `bash scripts/validate-kube.sh && bash scripts/smoke.sh`

Expected: PASS.

- [ ] **Step 5: Run cross-project gate and document evidence**

Run:

```bash
cd thought-khoral-contracts && npm test
cd ../thought-khoral-room-gateway && cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets
cd ../thought-khoral-agent-gateway && cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets
cd ../thought-khoral-workspace-ui && npm test && npm run build && npm run test:preview
cd ../thought-khoral-platform && bash scripts/validate-kube.sh && bash scripts/smoke.sh
cd .. && bash scripts/verify-spec-hierarchy.sh
```

Expected: all commands exit 0. If the identity verifier has unrelated baseline allowlist failures, list every path and do not claim a passing release gate until they are fixed.

- [ ] **Step 6: Commit platform and verified exclusions**

```bash
cd thought-khoral-platform && git add compose.yaml containers keycloak kube scripts README.md && git commit -m "feat: compose local A2A agent gateway foundation"
cd ../thought-khoral-agent-gateway && git add docs/verification README.md .ai/specs && git commit -m "docs: verify local A2A gateway foundation"
```

## Self-review

| Approved requirement | Tasks |
| --- | --- |
| Official A2A transport/Agent Card/task updates/artifacts | 4–5 |
| Local deterministic two-skill agent | 4–5 |
| Complete authorized context, revision, citations | 2–5 |
| Room authority and no direct agent DB access | 2–4, 7 |
| Progress, results, handoff presentation | 1–3, 5–7 |
| Zero trust | 2–5, 7 |
| Additive compatibility/fixtures/e2e evidence | 1, 6–7 |

The plan introduces every interface before later tasks consume it. It intentionally excludes remote admission, MCP, models/tools, context compaction/retrieval, agent-to-agent invocation, and ThoughtKhoral-owned human-interaction forms.
