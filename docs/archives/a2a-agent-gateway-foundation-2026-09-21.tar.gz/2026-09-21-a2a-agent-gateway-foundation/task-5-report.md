# Task 5 report — deterministic A2A Reference Agent and dispatcher

## Scope and implementation

Committed in `thought-khoral-agent-gateway` as
`a7907bc feat: dispatch deterministic A2A room tasks`.

`thought-khoral-agent-gateway` now has a deterministic local Reference Agent,
its pinned JSON-RPC adapter, one-lease dispatch worker, and pure governed
update/handoff validation. No contracts, room gateway, UI, platform, database,
filesystem, shell, model, tool, browser, URL-fetch, or external network path
was changed or added.

The production dispatch binary links only the already-pinned A2A core/client
packages. The official server is optional behind `reference-agent-server` and
is required only for the separate `thought-khoral-reference-agent` binary.
`cargo tree --no-default-features -e=no-dev` contains `a2a-lf` and
`a2a-client-lf`, not `a2a-server-lf`; enabling `reference-agent-server` adds
only the latter for the separate binary.

## Official SDK/server provenance

| Component | Published package / exact version | Official release tag / commit | Usage |
| --- | --- | --- | --- |
| Core | `a2a-lf = 0.3.0` | `a2a-lf-v0.3.0` / `903c7b564feae9fde30828e8037e3d0ea4dd9ca4` | Agent Card and A2A wire types |
| Client | `a2a-client-lf = 0.2.3` | `a2a-client-lf-v0.2.3` / `33b522ee17449bb93fdbe442aed1edf5498e78c7` | fixed loopback JSON-RPC transport |
| Server | `a2a-server-lf = 0.4.3` | `a2a-server-lf-v0.4.3` / `cd5a4a8fdcd3e69a505481f49e179af5315dec98` | feature-gated Reference Agent JSON-RPC router |

The committed lockfile pins the optional server package checksum to
`f9ea7cf23a50c687610120890983dda279e008e87f8003ff02b8e5dfbc9c17ef`.
The official server tag was checked with `git ls-remote --tags` on
2026-09-22. `docs/dependencies/a2a-rs.md` records the feature boundary and
provenance alongside Task 4's existing evidence.

## Deterministic and zero-trust rules

- The Reference Agent binary binds exactly `127.0.0.1:9090`; its only routes
  are the pinned Agent Card and `/jsonrpc`, both gated by the non-empty
  `THOUGHT_KHORAL_AGENT_GATEWAY_CLIENT_SECRET` bearer secret.
- Its Agent Card has only `JSONRPC` `1.0` at the fixed endpoint and exactly
  `summarize-context` and `extract-action-items` skills.
- It accepts exactly one A2A user text part containing `{"packet": ...}`.
  The adapter labels that part `application/json`; the server rejects any
  other part kind (including A2A URL parts),
  unknown agent/skill, malformed/duplicate event IDs, missing or mismatched
  invocation event/input, revision mismatch, hash mismatch, or expired packet.
- Canonical packet hashing repeats the broker's serialized field order and
  SHA-256 scheme. Adapter admission also checks task/room/revision/hash packet
  bindings and allows result citations only from visible packet event IDs.
- Every valid invocation emits precisely:
  `submitted`, `working("Reading authorized room context")`,
  `working("Preparing cited result")`, `completed`.
- `summarize-context` returns exactly
  `Room <room-id> revision <revision> has <message-count> messages and active decisions: <ordered titles or none>.`
  and cites each included event ID in packet order. It does not use message or
  decision-summary content.
- `extract-action-items` retains only exact lines of the form
  `- text | owner: value | due: value`, ignores all other lines, limits the
  result to 20 items, and cites only the matching `agent.task.requested` event.
- The dispatcher claims one lease, re-fetches the context, verifies matching
  task/room/revision/hash/token plus packet integrity/expiry, and then admits
  only that exact A2A stream. It maps to `accepted`, the two required `working`
  progress events, and a terminal success. Its UUIDv5 update IDs derive from
  `(task_id, A2A ordinal, kind)`; update timestamps derive from
  `(packet.issued_at, ordinal)` so exact retries are idempotent. Repeated phase
  text inside the configured interval is coalesced. Validation failures submit
  only `invalid_agent_response`, `context_expired`, or `execution_failed`.
- Handoff validation is pure: it permits only a non-empty bounded instruction,
  HTTPS/no-userinfo URL, matching lower-case registered host, unexpired time,
  and matching packet task/revision. It never fetches, opens, or executes the
  URL.

## TDD evidence

Initial RED command, run before Task 5 production modules existed:

```text
cargo test --test reference_agent_test --test dispatcher_test --test a2a_adapter_test
error[E0432]: unresolved imports ... a2a_adapter, dispatcher,
reference_agent, update_validation
```

The focused GREEN command passed 12 tests after implementation (5 Reference
Agent, 4 dispatcher, 3 adapter tests when the server feature is enabled).

A later feature-gated HTTP black-box RED found that A2A generic JSON `data`
parts round-trip integral fields as `7.0`, so the strict Rust packet decoder
rejected an otherwise valid request. The implementation was changed to use one
`application/json` text part, eliminating lossy generic JSON conversion. The
same test then passed against the official server router. A retry regression
also went RED because wall-clock update timestamps differed on replay; it is
GREEN with immutable packet-issued-time plus ordinal timestamps.

## Final verification

Run outside the normal filesystem sandbox because its policy denies loopback
`TcpListener::bind` before the existing local-client security tests execute:

```text
cargo fmt --check                                      # passed
cargo clippy --all-targets -- -D warnings              # passed
cargo test --all-targets                               # passed (3 lib + 16 integration tests)
cargo clippy --all-targets --features reference-agent-server -- -D warnings  # passed
cargo test --all-targets --features reference-agent-server                    # passed (3 lib + 18 integration tests)
git diff --check                                       # passed
```

The default test set excludes only the server-feature HTTP router tests; the
feature-enabled suite includes the authenticated Agent Card and black-box
JSON-RPC/SSE stream assertions.

## Operational concern

Both local processes must receive the same confidential
`THOUGHT_KHORAL_AGENT_GATEWAY_CLIENT_SECRET`. Deployment configuration must
provide it without logging or exposing it to browser workloads. The agent
listener is intentionally loopback-only; an external sidecar/service address
is not supported by this slice.

## Review remediation round 1 — 2026-09-22

This follow-up changes only the Task 5 agent-gateway slice; it does not alter
contracts, the room gateway, UI, or platform. SDK/server provenance and the
core/client versus optional-server feature boundary are unchanged.
Committed in `thought-khoral-agent-gateway` as
`486fa0a fix: harden deterministic A2A room dispatch`.

### RED/GREEN evidence

The following focused regressions were added before their corresponding
implementation changes. The RED runs demonstrated the reviewed behavior:

```text
adapter_rejects_well_formed_but_non_deterministic_terminal_results
  FAILED: forged summary was admitted
adapter_rejects_unbound_or_non_agent_a2a_status_events
  FAILED: submitted event with a different context was admitted
extract_action_items_rejects_whitespace_variants_of_the_literal_grammar
  FAILED: whitespace-normalized action lines were emitted
invalid_agent_response_creates_only_a_safe_terminal_failure
  FAILED: emitted invalid_agent_response instead of execution_failed
invalid_packet_failure_uses_the_published_invalid_task_input_code
  FAILED: emitted context_expired instead of invalid_task_input
dispatcher_retries_dropped_progress_and_success_responses_with_the_same_update_ids
  FAILED: first lost response returned DispatchError::Broker
```

GREEN verification after the fixes:

```text
cargo fmt --check                                                        # passed
cargo clippy --all-targets -- -D warnings                                # passed
cargo test --all-targets                                                  # passed (25 tests)
cargo clippy --all-targets --features reference-agent-server -- -D warnings  # passed
cargo test --all-targets --features reference-agent-server               # passed (27 tests)
git diff --check                                                         # passed
```

The exact published `room-event.schema.json` was additionally compiled with
its own AJV 2020 validator; complete external `agent.task.failed` events for
both `invalid_task_input` and `execution_failed` validated successfully.

### Remediated rules

- Failure construction is now closed over the two published contract values:
  `invalid_task_input` for an invalid packet and `execution_failed` for
  refetch, local-A2A, or response-admission failures. Internal branches remain
  separate; no internal detail becomes room-event data.
- Result admission recomputes the sole allowed result from the verified packet
  and compares JSON exactly. Therefore the summary text and packet-event
  citation array must match in full and in order; action items must be the
  exact literal parse of the matching `agent.task.requested.payload.input`,
  with exactly its invocation-event citation.
- Action parsing accepts only literal `- text | owner: value | due: value`
  lines with no leading/trailing whitespace in any field and bounded text,
  owner, and due values. There is no free-form action output path.
- Every fixed A2A event now binds the expected task and context. Both working
  updates also require the agent role, exact message/task/context identifiers,
  exactly one plain text part, and no metadata/extensions. Submitted/completed
  task state and the completed artifact/part shape are likewise exact.
- Progress coalescing was removed: the protocol’s two working entries are
  distinct required events. The configured interval is now only retry spacing.
  A failed update submission replays the immutable request (same UUIDv5 ID,
  payload, revision, and packet-issued-time timestamp) until the lease-backed
  packet expires. The recording broker now mirrors real claim/duplicate
  semantics: it accepts a persisted update whose response is lost, accepts the
  matching retry as an idempotent duplicate, and makes a terminal task
  non-claimable.

### Remaining operational boundary

The retry loop resolves transient request/response loss while the live lease
permits writes, including a lost terminal-success response. A full room-gateway
outage lasting beyond lease expiry cannot be settled by this binary because the
existing internal API exposes neither lease renewal nor task release/reclaim;
the dispatcher returns a broker failure after expiry rather than emitting an
invented terminal event. That gateway recovery policy is outside this Task 5
scope and was not changed.

## Final failure-schema regression — 2026-09-22

The enum-inspection regression was replaced with
`emitted_failed_updates_validate_against_the_pinned_room_event_schema` in the
agent-gateway dispatcher tests. It executes the real invalid-A2A-response and
invalid-packet dispatcher paths, reads their recorded `agent.task.failed`
updates, and hydrates them with exactly the external-task core that the room
gateway adds before persistence. The resulting full room-event instances are
validated against the pinned `room-event.schema.json` and its pinned envelope
resource using `jsonschema = 0.42.2` with default features disabled. This
keeps schema validation in-memory: it performs no file, HTTP, or URL retrieval.
Committed as `5100abe test: validate emitted task failures against room schema`.

Both actual emitted contract values (`execution_failed` and
`invalid_task_input`) validate successfully. Mutating the same emitted event
shape to the former internal-only `invalid_agent_response` or
`context_expired` code is rejected by the same compiled schema. Fresh verification passed `cargo fmt --check`,
default `cargo clippy --all-targets -- -D warnings` and `cargo test
--all-targets` (25 tests), plus the feature-enabled clippy/test suite (27
tests) and `git diff --check`.
