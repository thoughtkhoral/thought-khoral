# Task 7 — local A2A agent-gateway foundation report

## Delivered scope

The local platform now declares two internal-only workloads:

- `thought-khoral-reference-agent` binds its protected A2A Card and JSON-RPC
  endpoint only to `127.0.0.1:9090`.
- `thought-khoral-agent-gateway` shares that loopback namespace (Compose) or
  pod (Kubernetes) and is the only caller of that endpoint.

Both use UID/GID `10001`, a read-only root filesystem, no-new-privileges /
`allowPrivilegeEscalation: false`, a writable temporary filesystem only, no
host-published port, and no `DATABASE_URL`. The agent gateway receives only
the reviewed Keycloak service credentials, pinned Keycloak/room/Card
authorities, operational limits, and the reference agent's shared inbound
secret. The reference agent receives only that shared inbound secret.

The Kubernetes representation is intentionally a two-container Deployment,
not two routable Services: a separate pod or ClusterIP could not preserve the
reviewed fixed `http://127.0.0.1:9090/.well-known/agent-card.json` authority.
`kube/reference-agent.yaml` is an immutable boundary declaration and the
reference-agent container is co-located in `kube/agent-gateway.yaml`.

`scripts/smoke-agent-gateway.mjs` uses human PKCE/RPC to invoke both allowed
skills. It requires the durable sequence `progressed`, `progressed`,
`progressed`, `succeeded`, fixed progress contents, exactly one terminal
result, and a non-empty unique citation set. Its packet harness writes a
Bob-only targeted message, claims the resulting task through the room
gateway's workload-authenticated internal endpoint while the worker is
stopped, and asserts the actual serialized packet lacks both the hidden text
and the hidden event ID before issuing the capture task's terminal update.

## Commits

| Repository | Commit | Subject |
| --- | --- | --- |
| `thought-khoral-agent-gateway` | `d679fdf` | `fix: allow reviewed internal Keycloak origins` |
| `thought-khoral-platform` | `a589053` | `feat: compose local A2A agent gateway foundation` |
| `thought-khoral-agent-gateway` | `f484624` | `docs: verify local A2A gateway foundation` |

`d679fdf` is deliberately separate for independent review. It adds only the
two exact reviewed internal Keycloak token URLs (Compose and the Kube service
DNS name) to the existing loopback HTTP exception, plus a regression test. It
does not permit arbitrary `http` or hostname token origins.

## RED evidence first

Before adding the Compose workloads, the smoke assertions were changed to
expect the two service identities and their isolation boundary. The required
RED run was:

```text
$ node --check scripts/smoke-agent-gateway.mjs && bash scripts/smoke.sh
bootstrap lifecycle invariants passed
smoke: Compose services do not use the ThoughtKhoral identities:
thought-khoral-postgres
thought-khoral-keycloak
thought-khoral-room-gateway
thought-khoral-memory-engine
thought-khoral-workspace-ui
```

The Keycloak-origin regression test was also written before its configuration
implementation. Its RED output was:

```text
$ cargo test --test config_test
running 4 tests
...
test config_accepts_only_reviewed_internal_keycloak_http_origins ... FAILED
panic at tests/config_test.rs:64: first compose service URL
3 passed; 1 failed
```

The remote-build regression test was updated first as well; it initially
failed with:

```text
FAIL: remote build help does not document pinned component refs
```

## GREEN evidence

The narrow configuration fix passed its focused test and the full agent
gateway suite:

```text
$ cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets
test result: ok. 3 passed; 0 failed                    # lib
test result: ok. 3 passed; 0 failed                    # a2a_adapter_test
test result: ok. 4 passed; 0 failed                    # config_test
test result: ok. 7 passed; 0 failed                    # dispatcher_test
test result: ok. 6 passed; 0 failed                    # reference_agent_test
test result: ok. 2 passed; 0 failed                    # registry_test
test result: ok. 1 passed; 0 failed                    # room_client_test
```

Platform static checks after the implementation:

```text
$ node --check scripts/smoke-agent-gateway.mjs
$ sh -n scripts/smoke.sh
$ sh -n scripts/validate-kube.sh
$ sh -n scripts/build-remote.sh
$ bash scripts/test-validate-kube.sh
test-validate-kube: compatibility allowlist and legacy-label rejection passed
$ bash scripts/test-build-remote.sh
remote-build checks passed
$ podman-compose -f compose.yaml config --services
thought-khoral-postgres
thought-khoral-keycloak
thought-khoral-room-gateway
thought-khoral-memory-engine
thought-khoral-reference-agent
thought-khoral-agent-gateway
thought-khoral-workspace-ui
$ git diff --check
```

The remote-build script also rejects an empty agent-gateway or UI ref after
the interface extension.

## Full cross-project gate

The prescribed commands were executed. Their exact terminal outcomes follow.

| Command | Outcome |
| --- | --- |
| `cd thought-khoral-contracts && npm test` | PASS: `validated session authentication, request fixtures, and persisted event fixtures` |
| `cd thought-khoral-room-gateway && cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets` | BLOCKED by pre-existing test-environment prerequisite; format and clippy completed, then the one database integration test panicked: `DATABASE_URL must name a migrated PostgreSQL database: NotPresent` (`6 passed; 1 failed`). |
| `cd thought-khoral-agent-gateway && cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets` | PASS; all test groups listed in the GREEN evidence passed. |
| `cd thought-khoral-workspace-ui && npm test && npm run build && npm run test:preview` | PASS: `Test Files 7 passed (7)`, `Tests 81 passed (81)`; production build completed; preview says `Production preview rendered a visible Room conversation`; ChatStream preview test `18 passed (18)`. The only output was Vite's non-fatal chunk-size warning. |
| `cd thought-khoral-platform && bash scripts/validate-kube.sh && bash scripts/smoke.sh` | BLOCKED before smoke by an unavailable newly built image; exact final error: `Error: playing YAML file: encountered while bringing up pod thought-khoral-agent-gateway-pod: localhost/thought-khoral-reference-agent:dev: image not known`. |
| `cd .. && bash scripts/verify-spec-hierarchy.sh` | BLOCKED by absent sibling checkout, reporting `thought-khoral-memory-engine: missing ThoughtKhoral project directory`, followed by its expected missing `.ai/specs/{what,how,decisions}` and README paths. |

## Runtime verification limitation and baseline distinction

The implementation did not weaken Containerfiles, locked dependency builds,
or isolation settings to force a runtime pass.

1. The pre-existing local Compose build already depends on a sibling
   `thought-khoral-memory-engine/` source tree that is not present in this
   worktree. A normal `podman-compose -f compose.yaml up --build -d` fails
   during that existing build with:

   ```text
   Error: building at STEP "COPY thought-khoral-memory-engine/Cargo.toml thought-khoral-memory-engine/Cargo.lock ./":
   ... stat ... no such file or directory
   ```

   This is a baseline checkout failure, not introduced by the two new
   workloads. It also independently explains the hierarchy-verifier result.

2. Building the agent image directly bypassed that missing sibling but stalled
   at the external registry update inside Podman:

   ```text
   [1/2] STEP 5/5: RUN cargo build --locked --release --bin thought-khoral-agent-gateway
       Updating crates.io index
   ```

   No `localhost/thought-khoral-agent-gateway:dev` or
   `localhost/thought-khoral-reference-agent:dev` image existed afterwards,
   so `podman play kube` correctly rejected the reference image as unknown.

3. A direct smoke attempt against the old five-service stack completed the
   browser assertion:

   ```text
   bootstrap lifecycle invariants passed
   smoke: PostgreSQL is ready
   smoke: Keycloak realm discovery is ready
   smoke: gateway is ready
   smoke: memory-engine is ready
   smoke: UI is ready
   smoke: ThoughtKhoral browser title is ready
   browser-smoke: fresh PKCE session authenticated and joined the room
   ```

   It cannot prove the new A2A assertions without the two images. With the
   agent RPC timeout intentionally reduced only to capture a diagnostic, its
   final result was `agent-smoke: WebSocket response timed out after 2000ms`.
   The committed smoke now also explicitly requires both new Compose services
   to be running before entering the browser/A2A phase.

4. The room-gateway cross-project failure is a separate baseline invocation
   issue: its accepted existing test itself requires a migrated PostgreSQL
   `DATABASE_URL`, while the prescribed bare command supplies none. Task 7
   did not edit that repository.

To obtain the remaining runtime GREEN evidence, provide the missing
`thought-khoral-memory-engine` sibling (or an equivalent complete source root),
allow Podman to finish the locked Cargo build with registry access, start a
fresh/reimported local Keycloak realm containing the documented disposable
client secret, then rerun the exact platform command. Existing persisted
Keycloak realms do not automatically re-import an updated client secret.

No real secret, certificate, or private key was added.

## P1 follow-up — separate Keycloak and inbound credentials

The original local foundation incorrectly reused
`THOUGHT_KHORAL_AGENT_GATEWAY_CLIENT_SECRET` as the bearer secret accepted by
the reference agent. That allowed the reference-agent process to read the
Keycloak client credential and mint gateway workload tokens. The follow-up now
uses two deliberately distinct disposable fixtures:

| Credential | Fixture value | Recipients |
| --- | --- | --- |
| Keycloak client secret | `agent-gateway-client-dev-only` | agent gateway only; Keycloak realm fixture |
| A2A inbound bearer secret | `reference-agent-inbound-dev-only` | agent gateway and reference agent only |

`GatewayConfig` requires the inbound-secret variable and rejects it when it
equals the Keycloak client secret. The gateway binary uses the inbound variable
for Card discovery and A2A RPC; the reference-agent binary uses only that
variable. Compose and Kubernetes provide no
`THOUGHT_KHORAL_AGENT_GATEWAY_CLIENT_SECRET` variable to the reference-agent
container. The smoke harness's workload-token request uses the Keycloak client
fixture only; it never needs the A2A inbound secret.

P1 commits:

| Repository | Commit | Subject |
| --- | --- | --- |
| `thought-khoral-agent-gateway` | `cb9f678` | `fix: separate A2A inbound and Keycloak credentials` |
| `thought-khoral-platform` | `06a75c9` | `fix: isolate local A2A inbound credential` |

### P1 RED/GREEN evidence

The gateway configuration regression was written before enforcement. Its RED
run demonstrated that a missing inbound secret was accepted:

```text
$ cargo test --test config_test
running 5 tests
test config_requires_a_distinct_reference_agent_inbound_secret ... FAILED
assertion failed: GatewayConfig::parse(missing_inbound_secret).is_err()
4 passed; 1 failed
```

The platform regression injects
`THOUGHT_KHORAL_AGENT_GATEWAY_CLIENT_SECRET` into the reference-agent
container in a copied Kube fixture. Before validator enforcement, it was
incorrectly accepted:

```text
$ bash scripts/test-validate-kube.sh
test-validate-kube: validator accepted a Keycloak client secret in the reference-agent container
```

After the fix:

```text
$ cd thought-khoral-agent-gateway
$ cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets
test result: ok. 3 passed; 0 failed                    # lib
test result: ok. 3 passed; 0 failed                    # a2a_adapter_test
test result: ok. 5 passed; 0 failed                    # config_test
test result: ok. 7 passed; 0 failed                    # dispatcher_test
test result: ok. 6 passed; 0 failed                    # reference_agent_test
test result: ok. 2 passed; 0 failed                    # registry_test
test result: ok. 1 passed; 0 failed                    # room_client_test

$ cd ../thought-khoral-platform
$ node --check scripts/smoke-agent-gateway.mjs
$ sh -n scripts/smoke.sh && sh -n scripts/validate-kube.sh
$ bash scripts/test-validate-kube.sh
test-validate-kube: compatibility allowlist and legacy-label rejection passed
$ bash scripts/test-build-remote.sh
remote-build checks passed
$ podman-compose -f compose.yaml config --services
thought-khoral-postgres
thought-khoral-keycloak
thought-khoral-room-gateway
thought-khoral-memory-engine
thought-khoral-reference-agent
thought-khoral-agent-gateway
thought-khoral-workspace-ui
```

The P1 Kube run still reaches the already documented environment blocker only
after these static credential-boundary checks:

```text
Error: playing YAML file: encountered while bringing up pod thought-khoral-agent-gateway-pod: localhost/thought-khoral-reference-agent:dev: image not known
```

No real secret, certificate, or private key was added. The named values above
are disposable local development fixtures and must be replaced by separately
managed service and inbound credentials in deployment environments.

## P1 follow-up — per-container memory scratch and terminal observation

Commit `c4b7a86` in `thought-khoral-platform`
(`fix: isolate agent pod scratch storage`) corrects the Kubernetes scratch
boundary. The reference-agent and gateway containers now mount distinct
`reference-agent-tmp` and `agent-gateway-tmp` volumes at `/tmp`; each is an
`emptyDir` with `medium: Memory`. Neither container can use the other
container's writable scratch path, and the two paths are memory-backed rather
than node disk-backed.

The Kube validator now extracts each container's `/tmp` volume, requires the
names to differ, and requires each definition to have `medium: Memory`. Its
regression test first made both containers mount `shared-agent-tmp`, then
separately removed the memory medium. Before enforcement, both insecure
fixtures were accepted:

```text
$ bash scripts/test-validate-kube.sh
test-validate-kube: validator accepted a shared writable agent /tmp volume
test-validate-kube: validator accepted a disk-backed agent /tmp volume
```

After the change:

```text
$ node --check scripts/smoke-agent-gateway.mjs
$ sh -n scripts/validate-kube.sh
$ bash scripts/test-validate-kube.sh
test-validate-kube: compatibility allowlist and legacy-label rejection passed
$ git diff --check
```

The smoke harness formerly stopped reading task events immediately after the
first `agent.task.succeeded`, so its count could not observe a delayed second
success. It now keeps the human RPC socket under observation for a fixed two
seconds after every terminal result (eight configured local polling intervals)
and rejects *any* post-terminal lifecycle event for that task, including a
second success. Timed-out socket waiters are removed correctly before the next
skill invocation, so the observation window cannot swallow a later task's
event.

The no-Service sidecar layout remains intentional and approved: the sidecar
replaces a routable Kubernetes `Service` so the reviewed loopback-only Agent
Card authority remains `127.0.0.1:9090`, rather than gaining a ClusterIP
endpoint. This is documented in the platform README and in the reference-agent
boundary manifest.

The actual `bash scripts/validate-kube.sh` again completed the static
credential and scratch-space checks, then reached the existing external image
limitation:

```text
Error: playing YAML file: encountered while bringing up pod thought-khoral-agent-gateway-pod: localhost/thought-khoral-reference-agent:dev: image not known
```
