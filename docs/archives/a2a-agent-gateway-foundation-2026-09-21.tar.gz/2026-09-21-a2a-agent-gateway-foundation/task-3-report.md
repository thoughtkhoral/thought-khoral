# Task 3 report — broker authorized room context for agent tasks

## Commits

- `thought-khoral-room-gateway` — `d89a999 feat: broker authorized room context for agent tasks`
- `thought-khoral-platform` — `40322fe feat: add agent gateway workload identity`

## Test and migration setup

The gateway integration tests require a migrated PostgreSQL database. They were run with:

```sh
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n
```

The existing local database contained the Task 2 migration tables `agent_tasks` and
`agent_task_updates` (plus `_sqlx_migrations`). Task 3 adds no migration: it consumes the Task 2
lease/context/update persistence and adds an atomic fixed-agent queue claim query.

## TDD evidence

The integration test was created before route or workload-auth implementation. The intended RED
run was:

```sh
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n cargo test --test agent_service_test
```

It failed at `tests/agent_service_test.rs:191`: the missing internal route returned `404` where a
missing credential must return `401`.

After implementation, the focused regression test passed:

```text
test brokered_context_requires_the_agent_gateway_identity_and_a_matching_live_lease ... ok
test result: ok. 1 passed; 0 failed
```

Final gateway verification passed:

```sh
cargo fmt --check
cargo clippy --all-targets -- -D warnings
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n cargo test --all-targets
```

`cargo test --all-targets` exited `0`; all unit and integration suites passed.

## HTTP interfaces

All internal endpoints require `Authorization: Bearer <agent-gateway-client-credentials-JWT>`.

| Endpoint | Request | Success response |
| --- | --- | --- |
| `POST /internal/v1/agent-tasks/claim` | `{"leaseOwner":"<uuid>"}` (`ClaimRequest`) | `200` `ContextResponse`, or `204` when no eligible task exists |
| `GET /internal/v1/agent-tasks/{taskId}/context` | `X-Thought-Khoral-Lease-Token: <uuid>` | `200` `ContextResponse` |
| `POST /internal/v1/agent-tasks/{taskId}/updates` | Same lease header and `{"updateId":"<uuid>","contextRevision":<i64>,"update":{"eventType":...,"payload":...,"occurredAt":...}}` (`TaskUpdateRequest`) | `200` with replayed/persisted wire `events` |

`POST /claim` atomically selects the oldest eligible **queued** task for only Reference Agent
`74686f75-6768-746b-686f-72616c000003`; no task ID selector or alternate agent route exists.
The lease owner is returned as `leaseToken`, and both read/update paths reconstruct the complete
Task 2 lease from persisted task state rather than trusting caller-supplied expiry data.

`RoomContextPacket` contains `taskId`, `roomId`, `requesterId`, `agentId`, `skillId`,
`contextRevision`, `issuedAt`, `expiresAt`, `input`, ordered wire `events`, `activeDecisions`, and
`canonicalSha256`. Its SHA-256 is the lowercase hex digest of the canonical serialized packet
fields excluding the digest itself. Issue/expiry derive from the immutable lease interval, so a
second context read under that lease returns the identical packet hash. Decisions are replayed
from events through the fixed context revision, preserving packet immutability.

## Security checks

- Internal JWT validation is separate from `Actor`/WebSocket authentication: it creates no room
  human or agent identity and no service account role mapping.
- The token must be RS256, use a trusted JWKS `kid`, have the configured issuer, exact audience
  `thought-khoral-room-gateway`, `azp` `thought-khoral-agent-gateway`, `exp`, `sub`, and `iat`.
  It has zero clock leeway and a maximum 300-second issue-to-expiry lifetime.
- Missing/invalid/audience-mismatched tokens receive `401`; authenticated human or other-client
  tokens receive `403`. WebSocket authentication remains confined to `/ws`; internal HTTP routes
  do not accept its session-authentication flow.
- The existing replay visibility predicate was moved to `rooms` and reused for packets, filtering
  every event against the original human requester. Mentioned events for anyone else are excluded.
- A task-specific live lease capability is required for every context and update operation. Bad,
  expired, cross-task, or non-Reference-Agent leases receive `404` and cannot persist an update.
- An update must name the task packet's exact context revision. Task 2 remains the persistence
  authority for schema validation, lease re-checking, server-owned core payload fields, terminal
  state handling, and `updateId` idempotent replay. Only a successful validated store result is
  broadcast.

## Realm workload identity

The dedicated Keycloak client is confidential (`publicClient: false`, `clientAuthenticatorType:
client-secret`), service-account enabled, has browser/direct user grants disabled, a 300-second
access-token lifespan, and an access-token audience mapper for `thought-khoral-room-gateway`.
No client secret was committed.

## Review fix round 1

Gateway follow-up commit: `93dbcbb fix: harden agent task broker ordering`. The realm was reviewed
but unchanged: its only workload audience mapper remains the custom
`thought-khoral-room-gateway` audience, so this round creates no additional platform commit.

Focused RED evidence, captured before the fixes:

```text
task_enqueue_timestamp_is_not_backdated_from_client_occurrence_time ... FAILED
assertion failed: record.created_at > start.occurred_at

queued_claim_waits_for_the_locked_oldest_task ... FAILED
a strict FIFO claim must wait for the oldest row lock

brokered_context_requires_the_agent_gateway_identity_and_a_matching_live_lease ... FAILED
left: 422
right: 401
```

The last result is the malformed unauthenticated request: direct JSON extraction ran before
internal authentication. The same staged integration regression also exercises multi-audience
JWT rejection, conflicting update IDs, and hidden/foreign terminal citations.

Focused GREEN evidence:

```sh
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n \
  cargo test --test agent_task_store_test task_enqueue_timestamp_is_not_backdated_from_client_occurrence_time
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n \
  cargo test queued_claim_waits_for_the_locked_oldest_task
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n \
  cargo test --test agent_service_test
```

All three passed. Final fresh verification also passed: `cargo fmt --check`,
`cargo clippy --all-targets -- -D warnings`, and
`DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n cargo test --all-targets`
(7 unit tests, 86 integration tests, zero failures).

Review-round security and persistence changes:

- Task enqueue order is now database-owned (`created_at`/`updated_at` use `NOW()`), while the
  caller occurrence time stays only on the immutable requested event. Claims order by that enqueue
  time, and a transaction-scoped advisory lock per fixed agent plus `FOR UPDATE` serializes claims;
  there is no `SKIP LOCKED` bypass.
- Internal-route middleware authenticates the workload token before route body deserialization.
  `aud` must decode as one string exactly equal to `thought-khoral-room-gateway`; a JWT audience
  array, including one that contains that value, is rejected. `azp`, issuer, RS256/JWKS, lifetime,
  and all existing checks remain required.
- Before a terminal success can persist, the gateway reconstructs the exact live-lease packet at
  its stored revision, reuses `event_visible_to`, and accepts citations only from the packet's
  visible event IDs or active decision IDs. Hidden or foreign citations return `422` without a
  room-event write.
- Task 2's public update result interface remains compatible. The broker-only update outcome now
  marks exact `updateId` replays; a mismatched event type/payload/timestamp returns `409`, writes
  nothing, and is not published. Exact replays return their original event without republishing.
