### Task 3: Expose zero-trust room context and update endpoints

**Files:**
- Create: `thought-khoral-room-gateway/src/agent_service.rs`, `thought-khoral-room-gateway/tests/agent_service_test.rs`
- Modify: `thought-khoral-room-gateway/src/{auth,config,ws,rooms,lib}.rs`, `thought-khoral-platform/keycloak/thought-khoral-dev-realm.json`

**Interfaces:** `POST /internal/v1/agent-tasks/claim`; `GET /internal/v1/agent-tasks/{taskId}/context`; `POST /internal/v1/agent-tasks/{taskId}/updates`.

- [ ] **Step 1: Write failing internal-API integration tests**

Assert missing/user/wrong-audience tokens get 401/403; a valid agent-gateway client token can claim; an incorrect lease token reveals no context; duplicate `updateId` returns prior events.

- [ ] **Step 2: Run red**

Run: `cargo test --test agent_service_test`

Expected: FAIL because no routes or workload identity exist.

- [ ] **Step 3: Add Keycloak workload identity and internal token validation**

Create a confidential, service-account-enabled Keycloak client named `thought-khoral-agent-gateway` whose client-credentials token has audience `thought-khoral-room-gateway`. Add an internal validator that requires that audience and authorized-party/client ID; it must not map this token to a room `human|agent` role.

- [ ] **Step 4: Implement the narrow handlers and packet**

```rust
pub struct ClaimRequest { pub lease_owner: Uuid }
pub struct ContextResponse { pub packet: RoomContextPacket, pub lease_token: Uuid }
pub struct TaskUpdateRequest { pub update_id: Uuid, pub context_revision: i64, pub update: NormalizedAgentTaskUpdate }
```

Refactor WebSocket replay’s visibility predicate so packet creation filters all events through the requesting human’s current delivery visibility. Include ordered wire events through the revision, active decisions, task input, expiry, and a SHA-256 canonical-packet hash. Persist/broadcast only validated update events.

- [ ] **Step 5: Verify all gateway checks**

Run: `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets`

Expected: PASS; browser and reference-agent credentials cannot call internal routes.

- [ ] **Step 6: Commit**

```bash
cd thought-khoral-room-gateway && git add src tests && git commit -m "feat: broker authorized room context for agent tasks"
```

