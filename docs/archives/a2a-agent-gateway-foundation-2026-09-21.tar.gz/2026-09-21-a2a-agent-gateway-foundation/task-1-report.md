# Task 1 — governed external agent task contract

## Implementation

- Added the `agent.task.start` JSON-RPC request with the fixed envelope, UUID
  agent ID, allowlisted `summarize-context|extract-action-items` skill IDs, and
  a non-empty input bounded to 8,000 characters.
- Added bounded persisted event shapes for `agent.task.requested`,
  `agent.task.progressed`, `agent.task.awaiting_external_input`,
  `agent.task.succeeded`, and `agent.task.failed`. The external-task core
  requires `taskId`, `agentId`, `requesterId`, `skillId`, and
  `contextRevision`; progress and terminal result/failure shapes are bounded.
- Added safe handoff constraints (instruction, HTTPS URL, host, expiry only),
  discriminated success results, and UUID citation identifiers.
- Preserved the existing Action Items fixture unchanged by accepting the
  retained legacy Action Items event shape alongside the new governed external
  task `succeeded`/`failed` shapes.
- Added the five requested fixtures and explicit request assertions. The
  protocol now defines event ordering, durable progress/terminal behavior,
  context-packet citation visibility, and the no-secrets handoff boundary.
- Vendored the exact authoritative contracts tree into the room gateway and
  updated its lock to the local contracts commit. This local pin substitutes
  for a planned future external release tag; no tag or publish was created.

## RED evidence

Dependencies were absent in the isolated contracts worktree, so I first ran
`npm ci` there. Then this focused command failed as expected before the schema
implementation:

```text
$ cd thought-khoral-contracts && npm test

> thought-khoral-contracts@1.0.0 test
> node test/validate-fixtures.mjs

AssertionError [ERR_ASSERTION]: agent.task.start must validate: ...
data/method must be equal to one of the allowed values

false !== true
```

The failure is the intended unknown-method failure: `agent.task.start` was not
in the RPC method enum or any discriminated request branch.

## GREEN evidence

After the minimal schema, fixture, and protocol changes:

```text
$ cd thought-khoral-contracts && npm test

> thought-khoral-contracts@1.0.0 test
> node test/validate-fixtures.mjs

validated session authentication, request fixtures, and persisted event fixtures
```

The independently vendored snapshot was also verified:

```text
$ cd thought-khoral-room-gateway/contracts/n2n.room.v1 && npm test

> thought-khoral-contracts@1.0.0 test
> node test/validate-fixtures.mjs

validated session authentication, request fixtures, and persisted event fixtures
```

`git diff --check` passed in both repositories. A `git archive` extraction of
the contracts commit compared equal to `contracts/n2n.room.v1` (excluding the
ignored `node_modules` directory).

## Files changed

Contracts repository:

- `schemas/rpc.schema.json`
- `schemas/room-event.schema.json`
- `protocol.md`
- `test/validate-fixtures.mjs`
- `fixtures/valid/agent-task-start.json`
- `fixtures/invalid/agent-task-start-unknown-skill.json`
- `fixtures/events/valid/agent-task-progressed.json`
- `fixtures/events/valid/agent-task-summary-succeeded.json`
- `fixtures/events/invalid/agent-task-result-unknown-citation.json`

Room-gateway repository:

- `contracts/n2n.room.v1/**` exact vendor synchronization
- `contracts/lock.json`

## Commits and provenance

| Repository | Commit |
| --- | --- |
| `thought-khoral-contracts` | `bd7336a9ce92ca5ec3214757adc055476a8097b4` — `feat: add governed external agent task contract` |
| `thought-khoral-room-gateway` | `edf68591a68d2ef0c1a631babdb02e3a589589bb` — `chore: vendor governed external agent contract` |

The gateway lock records `tag: null`, the contracts commit above, archive SHA-256
`b7e2b9480be0ab07040cb8ce77b72bfb2bc819b05115983b9057f95d3ceab6c1`, and
schema SHA-256 values `6e24a837d1f0c6e2ff4e84e0b86b02161a1b51efaa219891e2cb9fc0a1f4c438`
(envelope), `8fc96f644a81cf54f3969c9c97567211e8d507558037b23d30acba371c9a68d6`
(RPC), and `453b0101ffc4b5ee293b4c0e5c02341b0b4b3d6249e52dd6eac3bd748e5eb122`
(room event).

## Self-review and concerns

- The retained legacy Action Items fixture continues to validate, while the
  external task variants are closed objects with bounded enums, arrays, text,
  and URL scheme.
- The invalid citation fixture verifies the contract-level UUID boundary.
  Whether a UUID citation was visible in a particular context packet is an
  event-history semantic check, documented as mandatory gateway behavior for
  the later runtime task rather than a JSON Schema-only relation.
- No external release/tag, runtime code, database changes, credentials, or
  network access were introduced.

## Review-fix addendum

### Fixed findings

- Governed `agent.task.start` now accepts only registered agent identity
  `74686f75-6768-746b-686f-72616c000003`. Every governed external-task event
  payload (`requested`, `progressed`, `awaiting_external_input`, `succeeded`,
  and `failed`) uses the same constrained schema definition. Retained legacy
  Action Items events preserve their existing compatibility shape.
- Added invalid request and event fixtures proving a different UUID is
  rejected.
- Handoff URLs now reject URI userinfo at the schema boundary. The fixture
  validator parses each persisted handoff, rejects URL usernames/passwords,
  and requires the persisted `host` to equal the parsed HTTPS URL host.
- Added invalid fixtures for credential-bearing handoff URLs and host mismatch;
  protocol documentation now makes both constraints explicit.

### Changed files

Authoritative contracts: `schemas/rpc.schema.json`,
`schemas/room-event.schema.json`, `protocol.md`,
`test/validate-fixtures.mjs`,
`fixtures/invalid/agent-task-start-unregistered-agent.json`, and
`fixtures/events/invalid/{agent-task-progressed-unregistered-agent.json,agent-task-handoff-url-userinfo.json,agent-task-handoff-host-mismatch.json}`.

The same authoritative artifact set was synchronized into
`thought-khoral-room-gateway/contracts/n2n.room.v1/**`; its
`contracts/lock.json` was repinned.

### Focused GREEN evidence

```text
$ cd thought-khoral-contracts && npm test

> thought-khoral-contracts@1.0.0 test
> node test/validate-fixtures.mjs

validated session authentication, request fixtures, and persisted event fixtures

$ cd thought-khoral-room-gateway/contracts/n2n.room.v1 && npm test

> thought-khoral-contracts@1.0.0 test
> node test/validate-fixtures.mjs

validated session authentication, request fixtures, and persisted event fixtures
```

`git diff --check` passed before both fix commits. An archive of the new
contracts commit compared byte-for-byte with the gateway snapshot (excluding
ignored `node_modules`).

### Fix commits and lock provenance

- Contracts: `1a44b6cfc19a4f5e668afb1ddb5241b2a0f1f72d` —
  `fix: constrain governed external agent handoffs`.
- Gateway vendor: `9b619af48a20412e18abadb536c91d8b282942ca` —
  `fix: pin constrained external agent contract`.
- Lock: no release tag; archive SHA-256
  `5074d1c33bf66123724d37bef5fca96992aa792e5650f0597c3c8e6b93ca72e2`.
