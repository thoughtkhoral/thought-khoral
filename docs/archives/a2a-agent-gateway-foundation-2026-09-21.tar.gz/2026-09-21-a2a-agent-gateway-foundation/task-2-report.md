# Task 2 recovery report — persist, lease, and start external tasks

## Inherited diff assessment

The interrupted implementation covered the task brief's required surfaces: a new
`agent_tasks`/`agent_task_updates` migration; typed `agent.task.start` parsing;
room-transaction persistence and request-ledger idempotency; human-only startup;
and a PostgreSQL-backed store for claiming, contextualizing, and updating tasks.
It retained the existing in-process Action Items behavior: that flow remains in
the `chat.send` path and was not changed.

Recovery review found two lease/state-integrity gaps in the inherited store:

1. A lease whose expiry had elapsed but had not yet been reclaimed still matched
   `context_for_lease` and `record_agent_task_update`.
2. A task in a terminal state could accept a distinct new update, despite the
   pinned contract specifying one terminal event.

The recovery adds database-time lease checks and prevents new updates after a
terminal state while preserving idempotent replay of the recorded update ID.

## Changed files

- `thought-khoral-room-gateway/migrations/0005_agent_tasks.sql`
- `thought-khoral-room-gateway/src/lib.rs`
- `thought-khoral-room-gateway/src/protocol.rs`
- `thought-khoral-room-gateway/src/rooms.rs`
- `thought-khoral-room-gateway/src/store.rs`
- `thought-khoral-room-gateway/tests/agent_task_store_test.rs`
- `thought-khoral-room-gateway/tests/protocol_test.rs`
- `thought-khoral-room-gateway/tests/room_flow_test.rs`
- `thought-khoral-room-gateway/tests/authorization_test.rs`
- This report: `.superpowers/sdd/2026-09-21-a2a-agent-gateway-foundation/task-2-report.md`

No vendor contract snapshot, other repository, internal HTTP/A2A, Keycloak, UI,
or platform file was changed.

## Migration and environment evidence

The first focused command without configuration failed before exercising the
store because `DATABASE_URL` was absent:

```text
cargo test --test agent_task_store_test --test protocol_test --test room_flow_test --test authorization_test
DATABASE_URL must name a migrated PostgreSQL database: NotPresent
```

The shared local `n2n` database contained `room_events`, `room_requests`,
`agent_tasks`, and `agent_task_updates`, but `_sqlx_migrations` existed with no
rows. As a result, replaying the whole migration chain there failed at migration
1 with `relation "room_events" already exists`. This is an environment ledger
condition, not an application failure.

Following the recovery direction, a uniquely named disposable database
`task2_agent_tasks_recovery_20260921` was created. Full migration execution
reported:

```text
Applied 1/migrate room events
Applied 2/migrate room events append only
Applied 3/migrate governed requests
Applied 4/migrate actor display names
Applied 5/migrate agent tasks
```

`sqlx migrate info` then reported all five migrations installed. The disposable
database was dropped after verification; a follow-up catalog query returned `0`.

## Transaction, idempotency, and lease semantics

- Task start locks the room, computes the next room-local revision, appends one
  immutable `agent.task.requested` event, creates a queued task record using that
  same revision, and records the request ledger in the surrounding transaction.
  A duplicate browser request returns its original event rather than appending a
  task or event.
- `claim_agent_task` atomically claims only queued/running/awaiting tasks whose
  lease is absent or expired; it moves queued work to running and returns a
  five-minute owner/expiry lease.
- Context is returned only when the persisted owner/expiry matches and the
  expiry is still in the future according to PostgreSQL. It contains events only
  through the captured context revision.
- Update recording locks the task and room, replays prior event IDs for a
  duplicate update ID without re-append, validates the active state, appends the
  agent event and update ledger entry, changes state, and commits atomically.
  Expired leases and new updates after terminal state are rejected; retrying the
  same terminal update while its lease remains valid returns the original event.

## Test evidence

All commands below used:

```text
DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/task2_agent_tasks_recovery_20260921
```

| Command | Result |
| --- | --- |
| `cargo test --test agent_task_store_test expired_lease_cannot_read_context_or_record_an_update` before fix | Expected RED: failed because `context_for_lease` returned `Some` for an expired matching lease. |
| Same command after fix | GREEN: 1 passed. |
| `cargo test --test agent_task_store_test terminal_task_replays_its_terminal_update_but_rejects_a_new_one` before fix | Expected RED: failed because a progressed update was accepted after success. |
| Same command after fix | GREEN: 1 passed. |
| `cargo fmt --check` | Passed after `cargo fmt`. |
| `cargo test --test agent_task_store_test --test protocol_test --test room_flow_test --test authorization_test` | Passed: 5 + 14 + 23 + 19 = 61 tests, 0 failed. |
| `cargo test` | Passed, including all unit and integration targets (no failures). |
| `git diff --check` | Passed with no output. |

The original worker's Task 2 RED observation was unavailable after interruption;
it is not fabricated here. The inherited task-start/claim/update tests therefore
have green evidence only. The two recovery regressions above have recorded
RED→GREEN evidence.

## Self-review and concerns

- Reviewed the request fingerprint, room lock, sequence/revision allocation,
  request ledger, migration constraints/indexes, role check, and the existing
  Action Items path. The room gateway starts durable external work only; it does
  not synchronously invoke an agent or expose database credentials.
- The separate `AgentTaskStore` helper has its own request-ledger branch for
  store tests; the normal WebSocket flow uses the pre-existing outer room
  transaction and records its ledger exactly once.
- This task establishes durable task storage and the leased update primitives.
  Citation visibility validation and external-agent HTTP/A2A orchestration are
  intentionally outside this task's scope and remain for their designated work.
