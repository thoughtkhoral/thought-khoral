# Task 4 report — zero-trust A2A agent-gateway foundation

## Commit and scope

- `thought-khoral-agent-gateway` — `9cd2f79 feat: add zero-trust A2A agent gateway foundation`

The new Rust crate provides only the foundation requested for the agent
gateway:

- strict `GatewayConfig` parsing for the exact room-gateway origin, fixed
  loopback Agent Card, Keycloak client-credentials identity, selected
  allowlisted handoff host, and bounded short lease/poll/update-rate settings;
- domain deserializers for the room gateway's Task 3 claim, context, lease, and
  update JSON contracts;
- a registry which accepts only Reference Agent
  `74686f75-6768-746b-686f-72616c000003`, its exact local JSON-RPC endpoint,
  protocol version, name, and the two allowed skills;
- a room-gateway HTTP adapter with `claim`, `fetch_context`, and
  `submit_update`, using a Keycloak client-credentials token provider and
  disabled redirects; and
- a startup binary that resolves the local Agent Card and validates the pin.

The crate has no SQLx/PostgreSQL dependency or database configuration, accepts
no browser/user bearer token, and has no dispatcher, reference-agent server,
or A2A task invocation. The test constructor accepts a static service token
only to prove the client authorization boundary; production construction uses
`ClientCredentialsTokenProvider` exclusively.

## Official A2A dependency review

Full evidence is committed as
`thought-khoral-agent-gateway/docs/dependencies/a2a-rs.md`.

| Rust dependency alias | Actual crates.io package | Locked version | Official tag / commit |
| --- | --- | --- | --- |
| `a2a` | `a2a-lf` | `0.3.0` | `a2a-lf-v0.3.0` / `903c7b564feae9fde30828e8037e3d0ea4dd9ca4` |
| `a2a-client` | `a2a-client-lf` | `0.2.3` | `a2a-client-lf-v0.2.3` / `33b522ee17449bb93fdbe442aed1edf5498e78c7` |

The releases are from the official `a2aproject/a2a-rs` repository. Their
tagged manifests state Apache-2.0 and Rust 1.85 MSRV; the current build uses
Rust 1.93.1. The official client supports HTTP+JSON/REST, JSON-RPC over HTTP,
and SSE response streaming. This slice directly adopts only the core and
client packages—not `a2a-server-lf`; `a2a-pb` is a transitive dependency of
the reviewed client package.

Evidence captured before writing the manifest included:

```text
git ls-remote --tags https://github.com/a2aproject/a2a-rs.git \
  a2a-client-lf-v0.2.3 a2a-lf-v0.3.0
33b522ee17449bb93fdbe442aed1edf5498e78c7 refs/tags/a2a-client-lf-v0.2.3
903c7b564feae9fde30828e8037e3d0ea4dd9ca4 refs/tags/a2a-lf-v0.3.0
```

`cargo metadata --locked --format-version 1` succeeded and reported
`a2a-client-lf 0.2.3` and `a2a-lf 0.3.0`. `cargo tree -i a2a-client-lf`
reported exactly:

```text
a2a-client-lf v0.2.3
└── thought-khoral-agent-gateway v0.1.0
```

For advisory evidence on 2026-09-22, `cargo-audit` 0.22.2 was installed into a
temporary directory with `--locked` (the first unconstrained install selected
`kstring 2.0.5`, which requires Rust 1.96). The completed command was:

```text
cargo audit --deny warnings
Loaded 1261 security advisories
Scanning Cargo.lock for vulnerabilities (252 crate dependencies)
```

It exited 0 with no RustSec vulnerability or warning.

## TDD evidence

The three integration-test files were created before `Cargo.toml` or any
production source. The required RED command was run first:

```text
cargo test --test config_test --test registry_test --test room_client_test
error: could not find `Cargo.toml` in `thought-khoral-agent-gateway` or any parent directory
```

This is the expected failure for the previously specification-only repository.
After the minimal crate implementation, the same focused command passed all
five tests:

- two config tests (reject remote card/unallowlisted handoff; require service
  identity and short limits),
- two registry tests (reject endpoint/skill drift; accept only fixed identity
  and two skills), and
- one room-client test (records exactly `Bearer service-token`, with no browser
  token parameter available to forward).

## Final verification

The following current-tree checks passed before commit:

```text
cargo metadata --locked --format-version 1
cargo tree -i a2a-client-lf
cargo fmt --check
cargo clippy --all-targets -- -D warnings
cargo test --all-targets
git diff --check
```

`cargo test --all-targets` passed all five integration tests (2 config + 2
registry + 1 room client) and both crate targets compiled successfully.

The normal filesystem sandbox intermittently/consistently rejects
`TcpListener::bind("127.0.0.1:0")` with `Operation not permitted`; the focused
room-client test reproduced that failure before any request was sent. The same
unchanged test and final full suite passed outside that sandbox, confirming a
sandbox loopback restriction rather than an application failure.

## Workspace note

Cargo generated `thought-khoral-agent-gateway/target/` during verification; it
remains untracked and was intentionally not included in the Task 4 commit.

## Fix round 1 — client construction and outbound transport hardening

Follow-up commit: `50f2da8 fix: harden agent gateway client boundaries`.

The follow-up addresses every Critical and Important review finding without
adding dispatch, a reference-agent server, or A2A task invocation.

### Critical: no release escape hatch for arbitrary bearer tokens or origins

- `StaticServiceTokenProvider` and `RoomGatewayClient::for_test` are now
  private and compiled only under `cfg(test)`. They are absent from the release
  artifact and from the crate's public API.
- `ServiceTokenProvider` and `ClientCredentialsTokenProvider` are private.
  `RoomGatewayClient::from_config` is the sole public construction path and it
  always creates the Keycloak client-credentials provider. No public method
  accepts a bearer token or token provider.
- `GatewayConfig` fields are private. Its room gateway is represented by an
  opaque `RoomGatewayOrigin`, constructible only by parsing one of the three
  code-reviewed internal origins: local `127.0.0.1:8080`, Compose service
  `thought-khoral-room-gateway:8080`, or the development Kubernetes service.
  Arbitrary HTTPS configuration no longer becomes a trusted service authority.

### Important: Agent Card and HTTP egress controls

- `PinnedAgentRegistration::resolve_pinned_card` constructs the official SDK
  resolver with a caller-supplied `reqwest` client configured with both
  `no_proxy()` and `Policy::none()`. It validates loopback-only card discovery
  before it creates an HTTP request.
- The Keycloak token and room-gateway clients share `secure_http_client`, which
  now also applies `no_proxy()` plus no redirects. Workload credentials cannot
  leave through ambient `HTTP(S)_PROXY` settings or a redirect.
- Regression tests prove a non-loopback card URL is rejected before fetch and
  a loopback card's redirect is treated as an error rather than followed.

### Low-cost hardening and provenance

- Handoff allowlist parsing now rejects both canonical IP addresses and dotted
  numeric literals such as `127.000.0.1`.
- `docs/dependencies/a2a-rs.md` records the SHA-256 of the official
  `a2a-client-lf-v0.2.3` source archive:
  `f37578041b7ce1bb275a9e2a00a474c811db1d3077712257c1f4f2394a3f23e4`.

### TDD and final verification

Before implementation, the new card-discovery tests failed to compile because
`PinnedAgentRegistration::resolve_pinned_card` did not exist. The added
non-canonical dotted-IP handoff case then produced a behavioral RED:

```text
assertion failed: GatewayConfig::parse(noncanonical_ip_handoff).is_err()
```

Both failures are GREEN after the targeted implementation. Fresh final
verification passed:

```text
cargo fmt --check
cargo clippy --all-targets -- -D warnings
cargo test --all-targets
cargo build --release
cargo metadata --locked --format-version 1
git diff --check
```

The full suite passed 9 tests: 3 internal regression tests, 3 config tests, 2
registry tests, and 1 public-construction test. As in the original round, the
loopback mock tests were executed outside the default sandbox because the
sandbox denies local listener binding before test code can run.
