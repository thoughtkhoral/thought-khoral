### Task 6: Render explicit task start, progress, citations, and handoffs

**Files:**
- Create: `thought-khoral-workspace-ui/src/features/room/{AgentTaskComposer,AgentTaskComposer.test}.tsx`
- Modify: `thought-khoral-workspace-ui/src/{api,api.test}.tsx`, `thought-khoral-workspace-ui/src/features/room/{ChatStream,ChatStream.test,ChatStream.css,RoomPage}.tsx`

**Interfaces:** Consumes Task 1 events; produces `agent.task.start` only for human users.

- [ ] **Step 1: Write failing UI tests**

Test requested → progressed → succeeded for both skills. Assert an accessible task card includes phase/result/citation. Assert the handoff anchor has `target="_blank"` and `rel="noopener noreferrer"`, host text, and no automatic navigation.

- [ ] **Step 2: Run red**

Run: `cd thought-khoral-workspace-ui && npm test -- --run src/api.test.ts src/features/room/ChatStream.test.tsx src/features/room/AgentTaskComposer.test.tsx`

Expected: FAIL because new event types/composer are absent.

- [ ] **Step 3: Extend strict projection and add composer**

Add discriminated task result/progress/handoff validation to `api.tsx` without weakening existing Action Items parsing. Add a human-only `AgentTaskComposer` with fixed Reference Agent, two-skill selection, ≤8000 input, and:

```ts
createRpcRequest('agent.task.start', roomId, { agentId: REFERENCE_AGENT_ID, skillId, input: input.trim() })
```

Do not make free-text `@` delivery invoke external work.

- [ ] **Step 4: Render safely and verify green**

Render citations as controls that focus/scroll to existing event IDs. Use no returned HTML and no `window.open`.

Run: `npm test && npm run build && npm run test:preview`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
cd thought-khoral-workspace-ui && git add src && git commit -m "feat: show governed external agent tasks"
```

