# Final residual-fix report

## Agent gateway

- Commit: `f4dd81c fix: bound Agent Card startup discovery`
- `A2aAdapter::resolve_pinned_card` retains the existing 10-second client
  timeout and disabled redirects, rejects non-success responses, checks a
  declared body length, and incrementally limits an Agent Card response to
  `64 KiB` before JSON deserialization.
- Added an oversized, otherwise-valid Agent Card regression using a response
  without a `Content-Length` header so the streaming bound is exercised.
- TDD evidence: the regression failed before the change and passed after it.

## Workspace UI

- Commit: `cefbf4d fix: make persisted citations focusable`
- Persisted room messages explicitly receive `tabIndex={-1}`. Citation clicks
  can therefore move focus to their ordinary message targets independently of
  PatternFly's current default root-element behavior.
- The lifecycle citation test now asserts each persisted source's tabindex as
  well as the existing citation-driven focus movement.

## Verification

- Gateway focused: `cargo test --test a2a_adapter_test startup_card_discovery_rejects_an_oversized_agent_card`
- Gateway formatting: `cargo fmt --check`
- Gateway full: `cargo test --all-features` — all tests passed.
- UI focused: `npm test -- --run src/features/room/ChatStream.test.tsx` — 19 tests passed.
- UI full: `npm test` — 83 tests passed.
- UI production build: `npm run build` — completed successfully. Vite emitted
  its existing large-chunk advisory only.

Both nested repositories were clean after their respective commits. The outer
worktree has no tracked residual changes; this report is stored in the
requested `.superpowers` task-artifact path.
