### Task 5: Implement deterministic A2A reference agent and dispatch worker

**Files:**
- Create: `thought-khoral-agent-gateway/src/{reference_agent,a2a_adapter,dispatcher,update_validation}.rs`
- Create: `thought-khoral-agent-gateway/src/bin/thought-khoral-reference-agent.rs`
- Create: `thought-khoral-agent-gateway/tests/{reference_agent,dispatcher,a2a_adapter}_test.rs`, `thought-khoral-agent-gateway/fixtures/{agent-card,context-packet}.json`
- Modify: `thought-khoral-agent-gateway/src/{lib,bin/thought-khoral-agent-gateway}.rs`

**Interfaces:** Consumes task leases and packets; produces idempotent normalized progress/terminal updates.

- [ ] **Step 1: Write failing A2A black-box tests**

Require fixed Agent Card and this stream:

```text
submitted → working("Reading authorized room context") → working("Preparing cited result") → completed
```

Assert `summarize-context` is stable from room ID/revision/decision titles/message count and cites included event IDs. Assert `extract-action-items` parses only `- text | owner: value | due: value` from task input and cites the invocation event.

- [ ] **Step 2: Run red**

Run: `cargo test --test reference_agent_test --test dispatcher_test --test a2a_adapter_test`

Expected: FAIL because no agent/dispatcher exists.

- [ ] **Step 3: Implement reference server and safe adapter**

Expose official A2A JSON-RPC/HTTP+JSON only on a local-only listener protected by the agent-gateway bearer secret. Reject unknown/expired/mismatched packet, citation, and skill data. No filesystem, database, shell, model, tools, URLs, or external network calls.

- [ ] **Step 4: Implement lease-to-terminal dispatch**

Claim one lease, fetch/verify task/agent/revision/hash/expiry, call the pinned A2A skill, and map allowed statuses/artifacts to `NormalizedAgentTaskUpdate`. Derive update IDs from `(task_id, A2A event ordinal, kind)`, coalesce repeated phase text by interval, always submit terminal result, and submit only safe `invalid_agent_response|context_expired|execution_failed` failures.

- [ ] **Step 5: Add handoff validation without navigation**

Allow only non-empty instruction, HTTPS URL, unexpired handoff, packet/task/revision binding, and registered destination host. Treat the URL as data: never fetch, spawn a browser, or shell it.

- [ ] **Step 6: Verify and commit**

Run: `cargo fmt --check && cargo clippy --all-targets -- -D warnings && cargo test --all-targets`

Expected: PASS; ordered progress/results are emitted once and invalid updates create no room submission.

```bash
cd thought-khoral-agent-gateway && git add src tests fixtures && git commit -m "feat: dispatch deterministic A2A room tasks"
```

