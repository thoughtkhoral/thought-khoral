# Final A2A remediation recovery report

Date: 2026-09-22. Worktree: `.worktrees/a2a-agent-gateway-foundation`.

## Outcome and commits

The final remediation changes are committed separately in the four affected
repositories. The contracts repository is unchanged. Application, contract,
database, UI, container-build, and Kubernetes-manifest checks pass. The complete
Compose smoke remains blocked by the local environment described below; it is
not reported as a passing release gate.

| Repository | Commit | Subject |
| --- | --- | --- |
| thought-khoral-room-gateway | `1c870e7` | fix: recover expired agent leases and enforce broker handoffs |
| thought-khoral-agent-gateway | `31256b3` | fix: bound A2A dispatch and consume authoritative task packets |
| thought-khoral-workspace-ui | `e21432e` | fix: project human task requests and focus lifecycle citations |
| thought-khoral-platform | `277808f` | fix: enforce agent egress boundaries in local deployments |

## Inherited diff assessment

The previous worker's uncommitted work was preserved and inspected before edits.
No reset, checkout reversal, or unrelated cleanup was performed.

- Agent gateway: 14 tracked files were already modified, with untracked local
  contract schemas, a vendored client, and `.gitignore`. This contained packet
  input consumption, bounded summaries/citations, deterministic rejection,
  incremental dispatch, deadline handling, stable renewed-lease timestamps,
  removal of ineffective lease/rate settings, and most raw SSE bounds.
- Room gateway: five tracked files were modified, plus the untracked real
  broker/A2A integration test. The preserved changes selected expired running
  and awaiting-input tasks and added the first store-level handoff checks.
- UI: five files contained human-request projection and lifecycle citation
  targets. A TypeScript cast in the new test did not compile and was corrected.
- Platform: only the untracked egress regression existed; deployment isolation
  had not yet been implemented.
- Root and contracts repositories were clean. The contract source remains
  commit `1a44b6cfc19a4f5e668afb1ddb5241b2a0f1f72d`.

The previous worker reported packet-input and result-bound RED/GREEN evidence.
This recovery does not claim to have observed those original RED runs; it
independently reran their regressions and executed actual broker packets against
the live official A2A reference server.

## Final requirement coverage

### Authoritative input and UI citations

The broker already places task input from storage in the canonical packet.
The reference agent now consumes that field and validates the invocation's
task/room/requester/agent/skill/revision bindings. It no longer requires an
`input` property on the public `agent.task.requested` event, where the published
contract forbids that property. The live integration test proves that a real
broker packet with a contract-valid invocation event executes both skills.

The UI accepts the human requester as the invocation actor, projects the
registered reference agent as the task identity, retains persisted lifecycle
event IDs, and supplies focusable targets for task events and other room events.
Existing message and decision targets remain usable. Citation clicks focus and
scroll to the persisted source; handoffs remain explicit human-click links.

### Recovery, replay, and terminal handling

The real polling query now admits queued tasks and expired running or
awaiting-input tasks, while retaining its transactional serialization and live
lease exclusion. The HTTP claim handler mints a new random lease capability for
every claim, including a claim from the same stable worker ID. The compatibility
`leaseOwner` request field is not reused as authorization. Tests prove old-token
context access is rejected after each recovery.

Dispatcher update IDs remain deterministic from task, ordinal, and kind.
Occurrence timestamps derive from the immutable invocation timestamp rather
than packet issue time, so a renewed lease replays the same update payload.
Deterministic HTTP rejection is not retried until lease expiry: a safe terminal
failure is submitted. Transient transport retries remain lease bounded.

### Bounded results and streams

Summary decision titles use a 7,000-character budget and at most 20 titles;
larger decision sets receive a bounded count description. Summary citations
are capped at 100. Action items are capped at 20 with bounded text/owner/due
fields. Results continue to be recomputed and compared deterministically.

The vendored official client has a narrowly documented local parser patch:
65,536 buffered SSE bytes, 131,072 total SSE bytes, at most eight raw frames
including skipped comments, and 65,536 bytes for a non-SSE JSON-RPC fallback
body. Limit failures terminate parsing; partial-frame EOF is rejected.
The application admits exactly four typed events. Invocation has a ten-second
timeout further limited to packet expiry minus two seconds for failure
submission. A one-slot channel allows durable progress while the stream is
still open; success is withheld until the complete stream is admitted.

The official package is `a2a-client-lf` 0.2.3. Its crates.io archive checksum is
`ab51522c48871829447ee296d65f98918a93891440d31dedd9800145cbaad159`.
The package records packaging commit `4fdb6a9e6016978cb35e3f91cc50ffd056ce21b5`;
release tag `a2a-client-lf-v0.2.3` points to
`33b522ee17449bb93fdbe442aed1edf5498e78c7`. The unmodified package source tree
was compared byte-for-byte with the official tag archive and was identical.
The Apache license, original and normalized manifests, provenance, and patch
description are retained. Only `src/jsonrpc.rs` differs from upstream source.

Contract tests now use three exact local schemas plus their SHA-256 lock,
without sibling paths or remote schema retrieval. The source pin has no release
tag; the documentation says so explicitly rather than claiming a tagged release.

### Handoff and configuration authority

The room gateway enforces policy before persistence: the registered reference
agent, matching task/revision/core bindings, a trimmed nonempty instruction,
HTTPS without userinfo or fragment, the exact registered destination host,
port 443, and expiry after now but no later than the live lease. Invalid
handoffs append no event. URLs are parsed as data and never fetched.

The five-minute lease is broker owned. The dispatcher permits three distinct
progress events per invocation. Unsupported gateway lease-duration and
progress-rate environment variables are rejected and removed from Compose and
Kubernetes. The poll interval remains configurable. These controls no longer
claim to enforce ineffective configurable rates or lease durations.

### Actual deployment egress enforcement

Compose adds a credential-free egress setup service on an internal network
shared only with room gateway and Keycloak. Both applications share that
filtered namespace, drop every capability, and run with distinct UIDs:
reference agent 10002, gateway 10001. The reference agent is loopback only.
The gateway additionally reaches only resolved broker/Keycloak destinations on
TCP 8080 and the configured DNS resolver on UDP/TCP 53.

IPv4 and IPv6 OUTPUT filters default to rejection. Original-destination
connection tracking handles Kubernetes Service DNAT. Kubernetes supplies the
same filter through a NET_ADMIN init container and adds a NetworkPolicy.
Neither application has NET_ADMIN or an API service-account token. Setup
failure prevents application startup. IP changes require namespace recreation;
the README documents the DNS-label/CNI prerequisites.

The new smoke probe checks allowed broker/token connections and denied
reference/external connections. A separate disposable Podman kernel probe
was actually executed during recovery: gateway UID 10001 received HTTP 400
from the live room `/ws` endpoint; reference UID 10002 was denied at that exact
IP and port; both UIDs were denied arbitrary IPv4 and IPv6 destinations
(`curl` exit 7, HTTP 000). The kernel rules were inspected for both families.
Keycloak was absent, so this isolated probe used an unreachable TEST-NET
placeholder for its allowlisted address; it does not claim a live token-service
connection. The full smoke retains that positive token-service assertion.

## RED evidence observed during recovery

1. Egress regression before deployment changes: two failures; applications were
   still on the old namespace and the Kubernetes egress init/policy were absent.
   After changes: all three structural/rule-behavior regressions pass.
2. Raw official-transport HTTP regression: `oversized or truncated SSE must
   fail` exposed silently discarded partial-frame EOF. After the parser fix,
   all oversized/comment/total-byte/partial-EOF cases pass.
3. Same-worker claim recovery: old capability returned HTTP 200 where the test
   required 404. After minting fresh capabilities, running and awaiting-input
   recovery and idempotent replay pass through the authenticated HTTP endpoint.
4. Handoff persistence: an HTTPS URL with a fragment was accepted. The
   regression now rejects fragments and whitespace-only instructions, alongside
   unregistered hosts, userinfo, HTTP, invalid expiry, and binding mismatches.
5. UI production build: TS2352 identified an unsafe broad event-array cast in
   the inherited test. Explicit literal typing restored compilation.

## Final verification evidence

Database commands used
`DATABASE_URL=postgres://n2n:n2n-dev-only@127.0.0.1:5432/n2n` with network access
approved for local tests. Initial sandbox `Operation not permitted` failures
were rerun outside the sandbox; they were not reported as product failures.

| Gate | Final result |
| --- | --- |
| Contracts `npm test` | PASS: request/event fixtures and authentication validation |
| Room `cargo fmt --check`, `cargo clippy --all-targets -- -D warnings`, database-backed `cargo test --all-targets` | PASS: 94 tests; the explicitly opt-in live test is ignored in this command |
| Room `cargo test --test agent_packet_live_test -- --ignored --nocapture` with local reference binary | PASS: actual broker packets execute both skills with citations |
| Agent `cargo fmt --check`, `cargo clippy --all-targets --all-features -- -D warnings`, `cargo test --all-targets --all-features` | PASS: 38 tests |
| UI `npm test` | PASS: 83 tests, seven files |
| UI `npm run build` | PASS; existing nonfatal large-chunk warning |
| UI `npm run test:preview` | PASS: visible production room; 19 ChatStream tests |
| Platform egress tests | PASS: three tests using the PyYAML-enabled podman-compose Python interpreter |
| Platform `test-validate-kube.sh`, `test-build-remote.sh`, shell syntax and smoke JS parse checks | PASS |
| Agent gateway, reference agent, egress image builds | PASS, locked Rust dependency builds retained |
| Platform `bash scripts/validate-kube.sh` | PASS: actual stopped workloads accepted by Podman, then cleaned up |
| Kernel egress probes | PASS: allowed room access and denied reference/arbitrary destinations |
| `git diff --check` in each changed repository | PASS |

One intermediate UI rerun while concurrent Rust/container builds were active
timed out in the pre-existing room-entry test (82/83). No unrelated product or
test timeout was changed. The full suite then passed with one worker (83/83)
and passed again with the normal `npm test` command (83/83).

## Remaining runtime/environment limitations

1. The worktree still lacks `thought-khoral-memory-engine/`. The hierarchy
   verifier reports the missing project directory, its three specification
   directories (`what`, `how`, `decisions`), and `.ai/specs/README.md`.
   This is the same source-checkout prerequisite documented in task 7 and
   prevents a complete normal source-based Compose rebuild.
2. The prior Podman crates.io stall is preserved as historical evidence in
   `task-7-report.md`, but it was resolved during this recovery. All three new
   images now build. It must no longer be cited as an active registry blocker.
3. The current local stack has no running Keycloak container. A short full
   smoke attempt passed PostgreSQL readiness and stopped at
   `Keycloak realm discovery did not become ready within 4s`. A complete smoke
   requires the full source checkout and a running/reimported local realm with
   the configured distinct disposable credentials. No full browser-to-terminal
   Compose pass is claimed from the narrower broker/A2A/kernel tests.
4. Podman does not implement Kubernetes NetworkPolicy. The manifest's policy
   is structurally checked; a production CNI/DNS deployment is outside this
   local foundation gate. The independently tested kernel filter also protects
   the Podman representation.

The temporary reference-agent process and disposable egress probe container
were stopped after verification. Built development images remain available.
Existing application containers and data were not intentionally replaced by
the kernel probe. No production secret, certificate, or private key was added.
