### Task 2: Persist, lease, and start external tasks in the room gateway

**Files:**
- Create: `thought-khoral-room-gateway/migrations/0005_agent_tasks.sql`, `thought-khoral-room-gateway/tests/agent_task_store_test.rs`
- Modify: `thought-khoral-room-gateway/src/{protocol,store,rooms,lib}.rs`, `thought-khoral-room-gateway/tests/{protocol_test,room_flow_test,authorization_test}.rs`

**Interfaces:** Produces `AgentTaskStart`, `AgentTaskRecord`, `AgentTaskLease`, `claim_agent_task`, `context_for_lease`, `record_agent_task_update`, and human-only task creation.

- [ ] **Step 1: Write failing transactional-store tests**

```rust
#[tokio::test]
async fn task_start_creates_one_requested_event_and_one_queued_record() {
    let store = test_store().await;
    let result = store.start_agent_task(test_task_start()).await.unwrap();
    assert_eq!(result.events.iter().filter(|event| event.kind == "agent.task.requested").count(), 1);
    assert_eq!(store.agent_task(result.task_id).await.unwrap().state, AgentTaskState::Queued);
}
#[tokio::test]
async fn expired_lease_can_be_claimed_again_but_live_lease_cannot() {
    let store = test_store().await;
    let task = store.start_agent_task(test_task_start()).await.unwrap().task_id;
    assert!(store.claim_agent_task(task, first_lease_owner(), now()).await.unwrap().is_some());
    assert!(store.claim_agent_task(task, second_lease_owner(), now()).await.unwrap().is_none());
    assert!(store.claim_agent_task(task, second_lease_owner(), expired_lease_time()).await.unwrap().is_some());
}
#[tokio::test]
async fn duplicate_update_id_returns_prior_events_without_reappend() {
    let store = test_store().await;
    let task = claimed_test_task(&store).await;
    let first = store.record_agent_task_update(task, test_progress_update()).await.unwrap();
    let replay = store.record_agent_task_update(task, test_progress_update()).await.unwrap();
    assert_eq!(first.events, replay.events);
    assert_eq!(store.room_event_count(test_room_id()).await.unwrap(), 2);
}
```

- [ ] **Step 2: Run red**

Run: `cd thought-khoral-room-gateway && cargo test --test agent_task_store_test`

Expected: FAIL because task types/store are absent.

- [ ] **Step 3: Add types, migration, and idempotent transaction behavior**

Add `AgentTaskStart` to `ValidatedRequest` and all match/fingerprint methods:

```rust
pub struct AgentTaskStart { pub id: String, pub contract_version: String, pub request_id: Uuid, pub room_id: Uuid, pub occurred_at: DateTime<Utc>, pub agent_id: Uuid, pub skill_id: AgentSkillId, pub input: String }
pub enum AgentSkillId { SummarizeContext, ExtractActionItems }
```

Create `agent_tasks` (task/room/requester/agent/skill/input/revision/state/lease/timestamps) and `agent_task_updates` with primary key `(task_id, update_id)`. Append `agent.task.requested`, allocate the revision after that event, and create the row in the existing room transaction.

- [ ] **Step 4: Enforce human authority**

Only `ActorRole::Human` may start a task. Duplicate browser request IDs return the original event. The room gateway does not invoke an agent synchronously and does not provide database credentials outside itself.

- [ ] **Step 5: Verify green**

Run: `cargo test --test agent_task_store_test --test protocol_test --test room_flow_test --test authorization_test`

Expected: PASS; no duplicate task and no agent caller can start one.

- [ ] **Step 6: Commit**

```bash
cd thought-khoral-room-gateway && git add migrations src tests && git commit -m "feat: persist governed external agent tasks"
```

