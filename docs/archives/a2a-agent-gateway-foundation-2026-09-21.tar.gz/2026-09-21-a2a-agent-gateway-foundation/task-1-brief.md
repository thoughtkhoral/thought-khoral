# Task 1: Publish additive external-agent task contract

## Files

- Modify: `thought-khoral-contracts/schemas/rpc.schema.json`, `thought-khoral-contracts/schemas/room-event.schema.json`, `thought-khoral-contracts/protocol.md`, `thought-khoral-contracts/test/validate-fixtures.mjs`
- Create: `thought-khoral-contracts/fixtures/{valid/agent-task-start.json,invalid/agent-task-start-unknown-skill.json,events/valid/agent-task-progressed.json,events/valid/agent-task-summary-succeeded.json,events/invalid/agent-task-result-unknown-citation.json}`
- Modify: `thought-khoral-room-gateway/contracts/<current-room-contract>/**`, `thought-khoral-room-gateway/contracts/lock.json`

## Interface

Produce browser RPC `agent.task.start { agentId, skillId, input }` and additive events `agent.task.requested|progressed|awaiting_external_input|succeeded|failed`.

## Steps

1. Write the fixtures and failing validator assertions. Use this fixed request shape:

```json
{"jsonrpc":"2.0","id":"agent-task-start-1","method":"agent.task.start","params":{"contractVersion":"<retained-room-contract-version>","requestId":"81000000-0000-4000-8000-000000000001","roomId":"10000000-0000-4000-8000-000000000001","occurredAt":"2026-09-21T12:00:00Z","agentId":"74686f75-6768-746b-686f-72616c000003","skillId":"summarize-context","input":"Summarize the room."}}
```

The invalid fixture differs only by `skillId: "unregistered-skill"`.

2. Run `cd thought-khoral-contracts && npm test`; it must fail because `agent.task.start` is unknown.

3. Add bounded discriminated schemas. Define skills as exactly `summarize-context|extract-action-items`; input ≤ 8000. Every new event requires `taskId`, `agentId`, `requesterId`, `skillId`, and `contextRevision`. Progress has phase `accepted|retrieving-context|working|finalizing`, text ≤ 512, optional percent 0–100. Success is one of `context-summary.v1 {summary,citations}` or `action-items.v1 {actionItems,citations}`. Preserve existing Action Items fixtures unchanged.

4. Document event order and safe handoff semantics: durable progress only at meaningful changes; terminal events never coalesce; citations name packet-visible UUID sources; a handoff has instruction, HTTPS URL, host, expiry only; browser/agent secrets never enter the contract.

5. Run `npm test`; it must pass. Do not create an external release/tag. Instead, update the existing room-gateway vendored snapshot and lock using the local contracts commit and hashes, and report that this substitutes for the planned future release tag.

6. Commit in the contracts repository:

```bash
git add schemas protocol.md fixtures test && git commit -m "feat: add governed external agent task contract"
```

Then commit the matching vendored snapshot and lock in the room-gateway repository:

```bash
git add contracts lock.json && git commit -m "chore: vendor governed external agent contract"
```

## Boundary and global constraints

- This is an additive, fixture-backed protocol change. Do not weaken retained behavior.
- Do not introduce runtime, database, agents, credentials, or network access.
- Work only in `/Users/rnaszcyn/Development/rh-n2n/.worktrees/a2a-agent-gateway-foundation/thought-khoral-contracts` and, after the contracts commit, update and separately commit the room-gateway vendored contract snapshot in `/Users/rnaszcyn/Development/rh-n2n/.worktrees/a2a-agent-gateway-foundation/thought-khoral-room-gateway`.
- Use test-first development: write/add the invalid fixtures and validator assertions, run the focused test and capture the expected RED failure before schema production changes, then implement minimal schema/docs work and capture GREEN.
