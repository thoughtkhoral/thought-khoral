# SDD ledger — plan: docs/superpowers/plans/2026-09-21-a2a-agent-gateway-foundation.md

## Execution setup

- Root worktree: `/Users/rnaszcyn/Development/rh-n2n/.worktrees/a2a-agent-gateway-foundation`
- Root branch/base: `feature/a2a-agent-gateway-foundation` from `8f456b0`
- Component branches: `feature/a2a-agent-gateway-foundation` in contracts, room gateway, agent gateway, workspace UI, and platform.
- Original contracts checkout contains an unrelated untracked `.DS_Store`; it is not present in this worktree and will not be touched.

## Preflight interface scan

| Tasks | Shared file or interface | Producer → consumer | Finding / ruling |
| --- | --- | --- | --- |
| 1 → 2 | additive task RPC and room events | Contract fixtures/schemas → room request and persisted event handling | Compatible: Task 2 consumes only the additive contract published and vendored by Task 1. |
| 1 → 6 | additive task RPC and room events | Contract fixtures/schemas → strict UI projection and composer | Compatible: Task 6 consumes the fixed agent/skill/event discriminators from Task 1. |
| 2 → 3 | task record, lease, revision, idempotency | transactional task storage → internal claim/context/update handlers | Compatible: Task 3 exposes the task authority created in Task 2; no direct store access crosses the service boundary. |
| 3 → 4 | room-gateway internal API and workload identity | authenticated task/context/update API → agent gateway room client | Compatible: Task 4 consumes only the narrow service API and client credentials established in Task 3. |
| 3 ↔ 7 | Keycloak realm and internal service policy | workload client definition → composed service identity | Compatible: Task 3 defines the client; Task 7 injects only its credentials and endpoint configuration. |
| 4 → 5 | agent registration, domain records, A2A client | pinned registration/client → reference-agent adapter and dispatcher | Compatible after the server-crate ruling below. |
| 5 → 6 | normalized task events/results/handoffs | dispatcher events → UI cards, citations, and click-only handoff | Compatible: Task 6 renders persisted room events only. |
| 5 → 7 | gateway and reference-agent binaries | deterministic services → isolated container/Kubernetes configuration | Compatible: Task 7 deploys services without database credentials or published reference-agent ports. |
| 6 → 7 | user task invocation and presentation | composer/projection → end-to-end smoke assertion | Compatible: smoke starts tasks via the same human RPC and observes durable events. |
| 7 → all | cross-project verification | implementation slices → end-to-end contract, runtime, and platform checks | Compatible: Task 7 is terminal and does not produce a new interface consumed later. |

## Per-task text scan

| Task | Tests, code, and file scope agree | Finding / ruling |
| --- | --- | --- |
| 1 | Yes | Additive schemas, fixtures, protocol documentation, and vendored snapshot agree. |
| 2 | Yes | Store tests exercise request, lease, and idempotency before task persistence code. |
| 3 | Yes | Authentication tests, service endpoints, packet filtering, and Keycloak workload identity agree. |
| 4 | Tension found | The task says use official core/client crates, while Task 5 requires an official A2A server for the reference agent. |
| 5 | Yes after Task 4 ruling | Deterministic server, adapter, dispatcher, and handoff tests agree with the zero-trust constraints. |
| 6 | Yes | UI tests and rendering behavior match the contract-only event projection. |
| 7 | Yes | Isolation assertions and end-to-end proof consume all prior outputs. |

Ruling: The agent-gateway binary uses only the pinned official A2A core/client crates; the separately packaged reference-agent binary may use the matching pinned official server crate solely to host the local A2A endpoint. This preserves the design’s adapter boundary and avoids an improvised protocol server. Cost if wrong: the dependency footprint grows by one reviewed official crate and must be revised if the selected release has no safe server API.

Ruling: Task 1 records the local contracts commit and content hashes in the vendored room-gateway snapshot instead of creating an external contract release/tag. Publishing is an external side effect outside this implementation workspace; the local immutable commit is sufficient for the dependency order. Cost if wrong: a later release process must replace the local reference with an official tag before external distribution.

## Task dispatches

- Task 1 base: root `8f456b0`; contracts `39b25c1`; room gateway `a48ee15`.
- Task 1 implementer: `/root/task1_contract`; report: `task-1-report.md`.
- Task 1: fix round 1/5 (2 addressed, 0 open — fixed registered agent identity and credential-safe handoff validation; contracts `bd7336a..1a44b6c`, gateway `edf6859..9b619af`).
- Task 1: complete (contracts `39b25c1..1a44b6c`, gateway `a48ee15..9b619af`, review clean).
- Task 2 base: room gateway `9b619af`.
- Task 2: Ruling: use a uniquely named disposable migrated PostgreSQL database for verification because the shared local database had schema objects with an empty `_sqlx_migrations` ledger. Cost if wrong: the test environment may mask a migration conflict unique to a pre-existing developer database; production migration compatibility remains covered by the migration chain.
- Task 2: complete (room gateway `9b619af..b6fb1ea`, review clean).

Ruling: Task 3 commits the Keycloak realm change in `thought-khoral-platform` separately from the room-gateway runtime commit, because the plan names a platform-owned file but its example commit stages only gateway source/tests. Cost if wrong: cross-repository deployment compatibility must be maintained through the paired commit hashes and reviewed again in Task 7.

Ruling: Because `ClaimRequest` intentionally contains only `lease_owner`, `POST /internal/v1/agent-tasks/claim` atomically claims the oldest eligible queued task bound to the fixed registered Reference Agent. Cost if wrong: initial scheduling is FIFO rather than caller-selected; later multi-agent admission must add an explicit authorized selector rather than overloading untrusted task input.

Ruling: Agent configuration permits only the exact reviewed internal Keycloak token origins needed by Compose and Kubernetes, in addition to loopback, with regression tests. Cost if wrong: a deployment naming change requires a deliberate code/config review; accepting arbitrary HTTP service origins would violate the pinned-identity boundary.

- Task 3 base: room gateway `b6fb1ea`; platform `b19839d`.
- Task 3: fix round 1/5 (6 addressed, 0 open — DB-owned serialized FIFO, visible citations, singleton audience, auth ordering, and safe idempotency; room gateway `d89a999..93dbcbb`).
- Task 3: complete (room gateway `b6fb1ea..93dbcbb`; platform `b19839d..40322fe`; review clean).
